import eslintConfigBase from '@kit/eslint-config/base.js';

export default eslintConfigBase;
