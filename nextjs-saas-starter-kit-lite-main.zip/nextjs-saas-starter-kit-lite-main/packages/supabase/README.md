# Supabase - @kit/supabase

This package is responsible for managing the Supabase client and various utilities related to Supabase.

Make sure the app installs the `@kit/supabase` package before using it.

```json
{
    "name": "my-app",
    "dependencies": {
        "@kit/supabase": "*"
    }
}
```